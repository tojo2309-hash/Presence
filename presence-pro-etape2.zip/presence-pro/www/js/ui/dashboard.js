import { tout, parDate, aujourdhui } from '../db.js';
export async function afficher(el) {
  const [menages, equipes, pres] = await Promise.all([tout('menages'), tout('equipes'), parDate(aujourdhui())]);
  const titulaires = menages.filter(m => m.titulaire).length;
  const remplacants = menages.filter(m => m.remplacant).length;
  const pt = pres.filter(p => p.statut === 'titulaire').length;
  const pr = pres.filter(p => p.statut === 'remplacant').length;
  const abs = pres.filter(p => p.statut === 'absent').length;
  const saisis = pt + pr + abs;
  const taux = menages.length ? Math.round((pt + pr) / menages.length * 100) : 0;
  const h = menages.filter(m => m.sexeT === 'M').length, f = menages.filter(m => m.sexeT === 'F').length;
  const c = (v, l, cl = '') => `<div class="carte ${cl}"><div class="val">${v}</div><div class="lib">${l}</div></div>`;
  el.innerHTML = `
    <p class="date">${new Date().toLocaleDateString('fr-FR', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}</p>
    ${menages.length ? '' : `<div class="bloc vide">Aucun ménage enregistré.<br><a class="btn" href="#import">Importer un fichier Excel</a></div>`}
    <div class="grille">
      ${c(menages.length, 'Ménages enregistrés')}${c(titulaires, 'Travailleurs titulaires')}${c(remplacants, 'Remplaçants')}
      ${c(equipes.length, 'Équipes')}${c(pt, 'Titulaires présents')}${c(pr, 'Remplaçants présents')}
      ${c(abs, 'Absences', 'alerte')}${c(taux + ' %', 'Taux de présence du jour', 'vert')}${c(h + ' H / ' + f + ' F', 'Répartition des titulaires')}
    </div>
    <div class="bloc"><h2>Présences du jour</h2><canvas id="gPres"></canvas></div>
    <div class="bloc"><h2>Hommes / Femmes</h2><canvas id="gSexe"></canvas></div>
    <div class="bloc"><h2>Activités du jour</h2><ul class="activite">
      <li>${saisis} ménage(s) pointé(s) sur ${menages.length}</li>
      <li>${menages.length - saisis} ménage(s) en attente de pointage</li></ul></div>`;
  if (window.Chart) {
    new Chart(el.querySelector('#gPres'), { type: 'bar',
      data: { labels: ['Titulaires', 'Remplaçants', 'Absents'], datasets: [{ data: [pt, pr, abs], backgroundColor: ['#1E8E5A', '#16436F', '#C0392B'], borderRadius: 8 }] },
      options: { plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true, ticks: { precision: 0 } } } } });
    new Chart(el.querySelector('#gSexe'), { type: 'doughnut',
      data: { labels: ['Hommes', 'Femmes'], datasets: [{ data: [h, f], backgroundColor: ['#0B2A4A', '#1E8E5A'] }] } });
  }
}
