import { ouvrir } from './db.js';
import { afficher as dashboard } from './ui/dashboard.js';
const ROUTES = [
  ['dashboard', 'Tableau de bord', '📊'], ['import', 'Import Excel', '📥', 4], ['travailleurs', 'Travailleurs', '👷', 6],
  ['equipes', 'Équipes', '👥', 5], ['presences', 'Présences', '✅', 7], ['historique', 'Historique', '🕘', 8],
  ['rapports', 'Rapports', '📄', 9], ['utilisateurs', 'Utilisateurs', '🔐', 3], ['parametres', 'Paramètres', '⚙️', 9]];
const menu = document.getElementById('menu'), voile = document.getElementById('voile');
menu.innerHTML = '<div class="marque">Gestion Présence Pro</div>' +
  ROUTES.map(r => `<a href="#${r[0]}" data-r="${r[0]}"><span>${r[2]}</span>${r[1]}</a>`).join('');
const basculer = on => { menu.classList.toggle('on', on); voile.classList.toggle('on', on); };
document.getElementById('btnMenu').onclick = () => basculer(true);
voile.onclick = () => basculer(false);
async function naviguer() {
  const id = (location.hash || '#dashboard').slice(1);
  const r = ROUTES.find(x => x[0] === id) || ROUTES[0];
  document.getElementById('titre').textContent = r[1];
  menu.querySelectorAll('a').forEach(a => a.classList.toggle('actif', a.dataset.r === r[0]));
  basculer(false);
  const vue = document.getElementById('vue');
  if (r[0] === 'dashboard') return dashboard(vue);
  vue.innerHTML = `<div class="bloc vide">Ce module sera livré à l'étape ${r[3]}.</div>`;
}
window.addEventListener('hashchange', naviguer);
ouvrir().then(naviguer);
