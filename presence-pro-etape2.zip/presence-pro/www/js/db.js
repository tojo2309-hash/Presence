// Base locale IndexedDB (hors ligne). Les mises à jour ajoutent des magasins par version, sans toucher aux données existantes.
const NOM = 'presence_pro', VERSION = 1;
let _db;
export function ouvrir() {
  if (_db) return Promise.resolve(_db);
  return new Promise((ok, ko) => {
    const r = indexedDB.open(NOM, VERSION);
    r.onupgradeneeded = e => {
      const d = r.result;
      if (e.oldVersion < 1) {
        d.createObjectStore('menages', { keyPath: 'code' });
        d.createObjectStore('equipes', { keyPath: 'id', autoIncrement: true });
        const p = d.createObjectStore('presences', { keyPath: 'cle' }); // cle = code|date : une seule présence par ménage et par jour
        p.createIndex('date', 'date');
        d.createObjectStore('parametres', { keyPath: 'cle' });
      }
    };
    r.onsuccess = () => { _db = r.result; ok(_db); };
    r.onerror = () => ko(r.error);
  });
}
export async function tout(magasin) {
  const d = await ouvrir();
  return new Promise((ok, ko) => {
    const q = d.transaction(magasin).objectStore(magasin).getAll();
    q.onsuccess = () => ok(q.result); q.onerror = () => ko(q.error);
  });
}
export async function parDate(date) {
  const d = await ouvrir();
  return new Promise((ok, ko) => {
    const q = d.transaction('presences').objectStore('presences').index('date').getAll(date);
    q.onsuccess = () => ok(q.result); q.onerror = () => ko(q.error);
  });
}
export const aujourdhui = () => new Date().toLocaleDateString('sv-SE'); // AAAA-MM-JJ
